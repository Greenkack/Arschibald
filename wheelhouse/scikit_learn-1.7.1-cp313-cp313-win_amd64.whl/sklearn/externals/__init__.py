
"""
External, bundled dependencies.

"""
