from zlib import *
