def exec_from_string(code_str):
    exec(code_str)
