import objgraph
def heap_analyze():
    objgraph.show_most_common_types()
