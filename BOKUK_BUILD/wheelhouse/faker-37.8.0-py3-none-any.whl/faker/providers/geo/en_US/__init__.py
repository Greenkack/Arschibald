from .. import Provider as BaseProvider


class Provider(BaseProvider):
    pass
