from . import print_version


if __name__ == "__main__":
    print_version()
