
__version__ = (0, 0, 1)
__author__ = "Ivan Grishaev"
__email__ = "ivan@grishaev.me"

from .function import *  # noqa
from .collection import *  # noqa
from .monad import *  # noqa
from .generic import *  # noqa
from .predicate import *  # noqa
